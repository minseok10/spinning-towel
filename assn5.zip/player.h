#pragma once //node ���� ������ ����
struct node {
	char name[22];
	char gender;
	char dept[21];
	int id;
	int group;
	struct node * next;
};
typedef struct node NODE;

void fileLoad(NODE * group[], char *);
void addPlayer(NODE * group[]);
void rmPlayer(NODE * group[]);
