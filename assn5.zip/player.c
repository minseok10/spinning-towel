#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"group.h"
#include"player.h"

void fileLoad(NODE * group[],char * filename) {
	FILE * players;
	NODE * temp;
	NODE * count;

	char tname[22];
	char tgender;
	char tdept[21];
	int tid;
	int tgroup; //�л� �Ż���������

	players = fopen(filename, "r");

	if (players == NULL) {
		printf("Cannot open file!\n"); //���� ����
		exit(403);
	}
	while (fscanf(players, " %[^\t] %c %s %d %d", tname, &tgender, tdept, &tid, &tgroup) != EOF) {
		temp = malloc(sizeof(NODE));
		strcpy(temp->name, tname);
		temp->gender = tgender;
		strcpy(temp->dept, tdept);
		temp->id = tid;
		temp->group = tgroup;
		temp->next = NULL;
		//temp��忡 �����ͺ���
		insertList(group, temp); //group �� temp��� ����
	}
	fclose(players); //���� �ݱ�
}

void addPlayer(NODE * group[]) {
	NODE * temp; //�� ���
	NODE * count;
	int tid; //�й��ĺ�
	int i;

	printf("StudentID: ");
	scanf("%d", &tid);
	for (i = 0; i < 5; i++) { //�й� duplicate check
		if (group[i] == NULL)
			continue;
		for (count = group[i]; 1; count = count->next) {
			if (count->id == tid) { //�����й� �߰�
				printf("Player already exists!");
				printf("\n%-18s %-6s %-10s %-10s %-6s\n", "Name", "Gender", "Dept", "StudentID", "Group");
				printf("%-18s %-6c %-10s %-10d %-6d\n", count->name, count->gender, count->dept, count->id, count->group);
				return;
			}
			if (count->next == group[i]) //�� �׷콺ĵ ��
				break;
		}
	}

	temp = malloc(sizeof(NODE));
	temp->id = tid;
	printf("Name: ");
	scanf(" %[^\n]", temp->name);
	printf("Gender: ");
	scanf(" %c", &(temp->gender));
	printf("Dept: ");
	scanf("%s", temp->dept);
	printf("Group: ");
	scanf("%d", &(temp->group));
	//�� ��� �ۼ� �� �Է�
	insertList(group, temp); //temp�� ����
	printf("Player successfully added to group %d.\n", temp->group);
}

void rmPlayer(NODE * group[]) {
	NODE * count;
	int tid;
	int i;

	printf("StudentID: ");
	scanf("%d", &tid);
	for (i = 0; i < 5; i++) { //�й���ġ scan
		if (group[i] == NULL)
			continue;
		for (count = group[i]; 1; count = count->next) {
			if (count->next->id == tid) { //count->next �� ��ġ�ϴ°� �˻�
				removeList(group, i, count); //count ������� ����
				printf("Player sucessfully removed from group %d.\n", i + 1);
				return;
			}
			if (count->next == group[i]) //�� �׷� �˻糡
				break;
		}
	}
	printf("Player does not exist!\n");
}
